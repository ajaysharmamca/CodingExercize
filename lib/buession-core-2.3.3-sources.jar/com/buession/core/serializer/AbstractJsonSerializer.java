/*
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license agreements.
 * See the NOTICE file distributed with this work for additional information regarding copyright ownership.
 * The ASF licenses this file to you under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and limitations under the License.
 *
 * =========================================================================================================
 *
 * This software consists of voluntary contributions made by many individuals on behalf of the
 * Apache Software Foundation. For more information on the Apache Software Foundation, please see
 * <http://www.apache.org/>.
 *
 * +-------------------------------------------------------------------------------------------------------+
 * | License: http://www.apache.org/licenses/LICENSE-2.0.txt 										       |
 * | Author: Yong.Teng <webmaster@buession.com> 													       |
 * | Copyright @ 2013-2023 Buession.com Inc.														       |
 * +-------------------------------------------------------------------------------------------------------+
 */
package com.buession.core.serializer;

import java.nio.charset.Charset;

/**
 * JSON 序列化抽象类
 *
 * @author Yong.Teng
 */
@Deprecated
public abstract class AbstractJsonSerializer extends AbstractSerializer implements JsonSerializer {

	@Override
	public <V> String serialize(final V object, final String charsetName) throws SerializerException {
		return serialize(object);
	}

	@Override
	public <V> String serialize(final V object, final Charset charset) throws SerializerException {
		return serialize(object);
	}

	@Override
	public <V> byte[] serializeAsBytes(final V object, final String charsetName) throws SerializerException {
		return serializeAsBytes(object);
	}

	@Override
	public <V> byte[] serializeAsBytes(final V object, final Charset charset) throws SerializerException {
		return serializeAsBytes(object);
	}

	@Deprecated
	@Override
	public <V> V deserialize(final String str, final String charsetName) throws SerializerException {
		return deserialize(str);
	}

	@Deprecated
	@Override
	public <V> V deserialize(final String str, final Charset charset) throws SerializerException {
		return deserialize(str);
	}

	@Deprecated
	@Override
	public <V> V deserialize(final byte[] bytes, final String charsetName) throws SerializerException {
		return deserialize(bytes);
	}

	@Deprecated
	@Override
	public <V> V deserialize(final byte[] bytes, final Charset charset) throws SerializerException {
		return deserialize(bytes);
	}

}
